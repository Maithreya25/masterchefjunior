The *ingredients* to make this *delicous sandwich* are as follows:-
1. Toasted Bread
2. Cheese Slice
3. Tomato Sauce
4. Butter