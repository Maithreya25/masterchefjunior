Follow this *recipe* to make the *cheese sandwich* 
1. Take two *fresh* *breads* and toast them in the *toaster*.
2. Take them out of the toaster and place the *cheese slice* on top of one bread.
3. Then take a *piece of butter* and place it on the cheese slice and let it melt.
4. After the butter melts place the *other bread* on it.
5. Finally put sufficient *tomato ketchup* on the sandwich and the delicous sandwich is ready.